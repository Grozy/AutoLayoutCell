//
//  AppDelegate.h
//  AutoLayout
//
//  Created by 孙国志 on 14-9-18.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
