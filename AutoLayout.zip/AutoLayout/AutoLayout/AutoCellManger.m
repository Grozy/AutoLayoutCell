//
//  AutoCellManger.m
//  AutoLayout
//
//  Created by 孙国志 on 14/11/21.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import "AutoCellManger.h"

#define SYNTHESIZE_ARC_SINGLETON_FOR_CLASS(SS_CLASSNAME)\
\
+ (SS_CLASSNAME*) sharedInstance	\
{\
static SS_CLASSNAME *instance;\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
instance = [[SS_CLASSNAME alloc] init];\
});\
return instance;\
}\

@interface AutoCellManger()

@property (nonatomic,strong) AutoCell *cell;

@end

@implementation AutoCellManger

SYNTHESIZE_ARC_SINGLETON_FOR_CLASS(AutoCellManger)

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.cell = nil;
        self.cells = [@{} mutableCopy];
    }
    return self;
}

- (void)addCellClassName:(NSString *)cellName
{
    self.cells[cellName] = [[NSClassFromString(cellName) alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
}

- (void)addCellClassNames:(NSArray *)cellNames
{
    [cellNames enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSString *cellName = obj;
        
        self.cells[cellName] = [[NSClassFromString(cellName) alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }];
}

- (CGFloat)autoHeightWith:(id)item cellName:(NSString *)cellName
{
    self.cell = self.cells[cellName];
    [self.cell bindWith:item];
    [self.cell setNeedsUpdateConstraints];
    [self.cell updateConstraintsIfNeeded];
    [self.cell.contentView setNeedsLayout];
    [self.cell.contentView layoutIfNeeded];
    
    return [self.cell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize].height;
}
@end
