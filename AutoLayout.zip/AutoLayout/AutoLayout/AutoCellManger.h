//
//  AutoCellManger.h
//  AutoLayout
//
//  Created by 孙国志 on 14/11/21.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AutoCell.h"
@interface AutoCellManger : NSObject

@property (nonatomic, strong) NSMutableDictionary *cells;
@property (nonatomic,assign) id shareObject;

+ (AutoCellManger *)sharedInstance;
/**
 添加需要管理的cell的类名
 @param cellName    所需绑定cell的类名
 */
- (void)addCellClassName:(NSString *)cellName;
/**
 添加需要管理的cell的类名
 @param cellNames    cellNames数组用于存放所需绑定cell
 */
- (void)addCellClassNames:(NSArray *)cellNames;
/**
 根据内容通过自动布局获得高度.
 @param item        绑定的item.
 @param cellName    所需绑定cell的类名
 */

- (CGFloat)autoHeightWith:(id)item cellName:(NSString *)cellName;

@end
