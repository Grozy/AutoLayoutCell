//
//  AutoLayoutCell.m
//  AutoLayout
//
//  Created by 孙国志 on 14/11/21.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import "AutoLayoutCell.h"

@interface AutoLayoutCell()

@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, strong) UIImageView *showImageView;
@end

@implementation AutoLayoutCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentLabel = [[UILabel alloc] init];
        self.contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
        self.contentLabel.font = [UIFont systemFontOfSize:13];
        self.contentLabel.preferredMaxLayoutWidth = 300.0;
        self.contentLabel.textColor = [UIColor redColor];
        self.contentLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.backgroundColor = [UIColor greenColor];
        [self.contentView addSubview:self.contentLabel];
        
        self.showImageView = [[UIImageView alloc] init];
        self.showImageView.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.showImageView];
        
        [self updateCellConstraints];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.contentLabel sizeToFit];//重置contentLabel的size
}

- (void)bindWith:(id)item
{
    [super bindWith:item];
    self.contentLabel.text = item;
    self.showImageView.image = [UIImage imageNamed:@"plane.png"];
}

- (void)updateCellConstraints
{
    NSDictionary *views = @{
                            @"content": self.contentLabel,
                            @"image"  : self.showImageView
                            };
    
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-10-[content]-10-|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"|-10-[image(100)]-|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[content]-10-[image(50)]-|" options:0 metrics:nil views:views]];
}

- (void)updateConstraints
{
    [super updateConstraints];
    [self updateCellConstraints];
}

@end
