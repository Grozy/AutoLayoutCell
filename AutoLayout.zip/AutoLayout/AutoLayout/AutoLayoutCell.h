//
//  AutoLayoutCell.h
//  AutoLayout
//
//  Created by 孙国志 on 14/11/21.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AutoCell.h"
@interface AutoLayoutCell : AutoCell

/**
 将item与cell绑定
 @param item Model对象.
 */
- (void)bindWith:(id)item;


@end
