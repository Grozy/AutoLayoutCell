//
//  main.m
//  AutoLayout
//
//  Created by 孙国志 on 14-9-18.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
void DefaultUncaughtExceptionHandler(NSException *exception);
void DefaultUncaughtExceptionHandler(NSException *exception)
{
    NSString *name = exception.name;
    NSString *reason = exception.reason;
    NSDictionary *userInfo = exception.userInfo;
    
    NSLog(@"name: %@, reason:%@, userInfo:%@",name, reason, userInfo);
    
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"name: %@, reason:%@, userInfo:%@",name, reason, userInfo] forKey:@"exception"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

int main(int argc, char * argv[])
{
    NSSetUncaughtExceptionHandler(DefaultUncaughtExceptionHandler);
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}