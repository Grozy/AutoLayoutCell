//
//  AutoCell.m
//  AutoLayout
//
//  Created by 孙国志 on 14/11/21.
//  Copyright (c) 2014年 孙国志. All rights reserved.
//

#import "AutoCell.h"

#define SYNTHESIZE_ARC_SINGLETON_FOR_CLASS(SS_CLASSNAME)\
\
+ (SS_CLASSNAME*) sharedInstance	\
{\
static SS_CLASSNAME *instance;\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
instance = [[SS_CLASSNAME alloc] init];\
});\
return instance;\
}\

@interface AutoCell()

@property (nonatomic, strong) id instance;
@property (nonatomic, strong) NSMutableDictionary *cells;

@end

@implementation AutoCell

SYNTHESIZE_ARC_SINGLETON_FOR_CLASS(AutoCell)

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.cells = [@{} mutableCopy];
    }
    return self;
}
- (void)bindWith:(id)item
{
    NSAssert(YES, @"子类实现");
}

+ (CGFloat)autoHeightWith:(id)item
{
    [[[self class] sharedInstance] setCellClassName:NSStringFromClass([self class])];
    return [[[self class] sharedInstance] autoHeightWith:item cellName:NSStringFromClass([self class])];
}

- (void)setCellClassName:(NSString *)cellName
{
    self.cells[cellName] = [[NSClassFromString(cellName) alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
}

- (CGFloat)autoHeightWith:(id)item cellName:(NSString *)cellName
{
    AutoCell *cell = self.cells[cellName];
    cell = self.cells[cellName];
    [cell bindWith:item];
    [cell setNeedsUpdateConstraints];
    [cell updateConstraintsIfNeeded];
    [cell.contentView setNeedsLayout]; //将view的layout无效化，并在下一个update cycle
    [cell.contentView layoutIfNeeded]; //
    CGFloat cellHeight = [cell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize].height;
    [self.cells removeObjectForKey:cellName];
    return cellHeight;
}

@end
